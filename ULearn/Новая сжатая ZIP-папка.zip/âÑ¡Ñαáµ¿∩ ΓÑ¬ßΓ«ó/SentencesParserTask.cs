﻿using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;

namespace TextAnalysis
{
    static class SentencesParserTask
    {
        public static List<List<string>> ParseSentences(string text)
        {
			var sentencesList = new List<List<string>>(); //Лист предложений

				var doheraPredlojenii = text.Split('.', '!', '?', ';', ':', '(', ')'); //Разбиваем текст на предложения
			
				foreach (var predlojenie in doheraPredlojenii) //Пытаемся разбить предложения на слова
				{
					List<string> sentences = new List<string>(); //Лист слов
					var schetchik = 0;
					string stroka = "";

					while (schetchik < predlojenie.Length)
					{

						if (char.IsLetter(predlojenie, schetchik) || (predlojenie[schetchik] == '\''))
						{
							stroka += predlojenie[schetchik];
							stroka = stroka.ToLower();
						}

						else
						{
							if (stroka.Length != 0)
							{
								sentences.Add(stroka); //Добавляем цельное слово в лист слов
								stroka = ""; //Очищаем строку, чтобы при добавлении следующего слова не уходил повтор
							}
						}

						schetchik++;
					}

					if (stroka.Length != 0)
					{
						sentences.Add(stroka);
						sentencesList.Add(sentences);
					}

			}

			return sentencesList;
        }
    }
}